



<div><?php echo e($key); ?>.<?php echo e($post['title']); ?></div>



<?php /**PATH C:\xampp\htdocs\example-app\example-app\resources\views/posts/partials/post.blade.php ENDPATH**/ ?>