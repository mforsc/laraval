

<?php $__env->startSection('title', 'Home Page'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Hello World!</h1>
    
    
    <div>
        <?php for($i = 0; $i < 10; $i++): ?>
            <div>The current value is <?php echo e($i); ?></div>
        <?php endfor; ?>
    </div>

    <div>
    <?php $done = false ?>
    <?php while(!$done): ?>
    <div>I'm not done!</div>
        
        <?php
          if (random_int(0,1) === 1) $done = true  
        ?>
    <?php endwhile; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\example-app\example-app\resources\views/home/index.blade.php ENDPATH**/ ?>