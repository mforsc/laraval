@extends('layouts.app')

@section('title', 'Contact Page')

@section('content')
    <h1>Contact Page!</h1>
@endsection